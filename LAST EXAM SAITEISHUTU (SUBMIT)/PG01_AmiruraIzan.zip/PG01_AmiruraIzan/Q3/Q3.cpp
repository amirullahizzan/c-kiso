#include <iostream>
#include <string>
#include <sstream>

using namespace std;


int main()
{
	//Printing images

	const int SAMPLE_AMOUNT = 3;


	//////////////////////////////////////
	//DATA 0-1
	//1 -1 -1 -1 1 -1 -1 -1 -1 1 1 -1 1 1 -1 -1 1 -1 -1 -1 1 -1 -1 -1 -1 1 -1 1 -1 -1 -1 1 1 1 -1 1 -1 1 1 -1 1 1 1 -1 -1 1 1 -1 -1 1 -1 1 1 -1 1 1 -1 -1 1 -1 -1 1 1 -1 1 1 1 -1 1 1 1 1 -1 -1 -1 1 1 -1 1 -1 -1 -1 1 -1 -1 1 1 -1 -1 -1 -1 1 1 1 -1 1 1 1 1 -1

	//DATA 0-2
	//1 -1 1 1 -1 -1 1 1 -1 -1 1 1 1 -1 -1 -1 1 -1 -1 -1 1 1 -1 -1 -1 -1 1 1 -1 1 -1 -1 -1 1 1 1 1 -1 -1 -1 1 1 1 -1 -1 -1 1 1 1 1 -1 1 -1 1 -1 -1 -1 -1 1 -1 -1 -1 -1 1 -1 -1 1 -1 1 -1 1 1 -1 1 -1 1 1 -1 -1 -1 -1 1 1 -1 1 -1 -1 -1 1 1 -1 1 1 -1 1 -1 -1 1 1 -1
	
	////////////////////////////////////
	//DATA 1-1
	//-1 -1 1 1 1 1 -1 -1 1 -1 -1 1 -1 -1 1 -1 -1 -1 -1 1 -1 -1 -1 -1 1 1 -1 -1 1 -1 -1 -1 -1 -1 -1 -1 -1 -1 1 1 1 -1 -1 1 -1 1 -1 -1 -1 1 -1 -1 -1 -1 -1 -1 1 1 -1 -1 -1 1 -1 -1 1 -1 1 1 1 -1 -1 -1 1 -1 -1 1 1 1 -1 1 -1 1 -1 -1 1 1 -1 1 1 1 1 -1 -1 -1 1 1 -1 1 -1 -1
	
	//DATA 1-2
	//-1 -1 1 -1 -1 1 -1 -1 -1 -1 1 -1 1 -1 -1 -1 1 -1 -1 -1 -1 1 1 1 1 1 -1 1 -1 -1 1 1 -1 -1 1 -1 -1 -1 -1 1 -1 1 -1 -1 1 -1 -1 -1 1 1 -1 -1 1 -1 -1 -1 1 -1 1 1 -1 1 1 1 -1 -1 -1 -1 -1 1 -1 -1 1 -1 -1 -1 1 -1 1 1 -1 -1 1 -1 1 -1 1 -1 1 -1 1 -1 -1 1 -1 1 -1 -1 -1 1
	
	////////////////////////////////////
	//DATA 2-1
	//1 1 -1 -1 1 -1 1 -1 -1 -1 -1 -1 1 1 -1 1 -1 -1 1 -1 -1 1 -1 1 1 -1 -1 1 1 -1 -1 1 1 -1 -1 1 1 1 1 1 -1 -1 -1 -1 1 -1 1 1 -1 -1 -1 1 -1 -1 -1 1 -1 -1 -1 -1 -1 1 -1 -1 1 -1 1 -1 -1 -1 1 1 -1 -1 1 -1 -1 -1 -1 1 1 -1 -1 -1 -1 -1 -1 1 1 1 1 -1 1 1 -1 -1 -1 1 -1 1
	
	//DATA 2-2
	//-1 -1 1 -1 -1 -1 1 1 -1 1 1 1 1 -1 1 1 1 1 -1 -1 -1 1 1 1 1 1 1 1 -1 1 -1 1 -1 1 1 1 -1 -1 1 -1 -1 -1 1 1 -1 -1 -1 1 1 1 1 -1 -1 -1 -1 -1 -1 1 1 -1 -1 -1 1 1 1 1 -1 1 1 -1 -1 -1 1 -1 1 -1 1 1 -1 -1 1 1 1 -1 -1 1 -1 -1 1 -1 -1 1 1 1 -1 1 1 1 -1 -1

	for (int graph_i = 0; graph_i < SAMPLE_AMOUNT; graph_i++)
	{

		std::cout << "�y�}";
		printf("%02d", graph_i);
		std::cout << "�z" << endl;

		string input;
		getline(cin, input);

		const int MAX_GRID_SIZE = 10;

		string emptyDiamond[MAX_GRID_SIZE][MAX_GRID_SIZE];
		string filledDiamond[MAX_GRID_SIZE][MAX_GRID_SIZE];

		stringstream inputSstr(input);


		for (int i = 0; i < MAX_GRID_SIZE; i++)
		{
			for (int j = 0; j < MAX_GRID_SIZE; j++)
			{
				if (inputSstr >> input)
				{
					emptyDiamond[i][j] = input;
				}
			}
		}

		getline(cin, input);

		inputSstr.clear();
		inputSstr.str(input);

		for (int i = 0; i < MAX_GRID_SIZE; i++)
		{
			for (int j = 0; j < MAX_GRID_SIZE; j++)
			{
				if (inputSstr >> input)
				{
					filledDiamond[i][j] = input;
				}
			}
		}


		//COMBINE GRID
		string combinedDiamond[MAX_GRID_SIZE][MAX_GRID_SIZE];

		for (int i = 0; i < MAX_GRID_SIZE; i++)
		{
			for (int j = 0; j < MAX_GRID_SIZE; j++)
			{
				int emptyValue = stoi(emptyDiamond[i][j]);
				int filledValue = stoi(filledDiamond[i][j]);

				if (emptyValue == 1 && filledValue == 1) //�d�Ȃ�
				{
					combinedDiamond[i][j] = "�@";
				}
				else if (emptyValue == -1 && filledValue == -1) //�����Ȃ�
				{
					combinedDiamond[i][j] = "�@";
				}
				else if (emptyValue == 1 && filledValue == -1)
				{
					combinedDiamond[i][j] = "��";
				}
				else if (emptyValue == -1 && filledValue == 1)
				{
					combinedDiamond[i][j] = "��";
				}

			}
		}


		//�o��

		std::cout << "�y�}";
		printf("%02d", graph_i);
		std::cout << "�z" << endl;

		for (int i = 0; i < MAX_GRID_SIZE; i++)
		{
			for (int j = 0; j < MAX_GRID_SIZE; j++)
			{
				std::cout << combinedDiamond[i][j];
			}
			cout << endl;
		}

		cout << endl;
	}


	system("pause");
	return 0;
}