#include <iostream>
#include <string>
#include <sstream>

using namespace std;

int main()
{
	//PATTERN RECOGNITION PROGRAM

	//����
	const int MAX_INPUT = 6;

	string input[MAX_INPUT];
	for (int i = 0; i < MAX_INPUT; i++)
	{
		getline(cin, input[i]);
	}

	//SSTRING
	string correctAnswer[MAX_INPUT];
	int charactersAtATime[MAX_INPUT], loopTimes[MAX_INPUT];
	string answerGuess[MAX_INPUT];

	for (int i = 0; i < MAX_INPUT; i++)
	{
		stringstream inputSstr(input[i]);
		inputSstr >> correctAnswer[i] >> charactersAtATime[i] >> loopTimes[i] >> answerGuess[i];
	}

	//PASSWORD 2 4 PSRA
	//JArTnZRKUQm 2 12 JTRQAnKmrZUJ
	//NdQnSFZhRWjmL 3 20 NnZ
	//kWQAhJDMBniSx 2 4 kkkk
	//EbjkZumWLsq 12 3 EjZ
	//yreCnWzsKjpHU 9 12 yjWrpzeHsCUK

	//�F�؊m�F

	for (int i = 0; i < MAX_INPUT; i++)
	{

		string generatedPasswordPattern;
		int count = 0;

		for (int j = 0; j < loopTimes[i]; j++)
		{
			count = (j * (charactersAtATime[i] + 1)) % correctAnswer[i].length();
			//cout << count << endl;
			generatedPasswordPattern += correctAnswer[i][count]; //Appends
		}
		cout << "���͂��ꂽ�p�X���[�h " << "�u" << answerGuess[i] << "�v" << " - " << flush;

		if (answerGuess[i] == generatedPasswordPattern)
		{
			std::cout << "OPEN";
		}
		else
		{
			std::cout << "NG";
		}

		cout << endl;

	}

	system("pause");
	return 0;
}


////����
//const int MAX_INPUT = 5;
//
//string input;
//getline(cin, input);
//stringstream inputSstr(input);
//
////SSTRING
//string correctAnswer;
//int charactersAtATime, loopTimes;
//string answerGuess;
//inputSstr >> correctAnswer >> charactersAtATime >> loopTimes >> answerGuess;
//
////PASSWORD 2 4 PSRA
//
////�F�؊m�F
//
//string generatedPasswordPattern;
//int count = 0;
//
//for (int i = 0; i < loopTimes; i++)
//{
//	count = (i * (charactersAtATime + 1)) % correctAnswer.length();
//	cout << count << endl;
//	generatedPasswordPattern += correctAnswer[count]; //Appends
//}
//cout << "���͂��ꂽ�p�X���[�h " << "�u" << answerGuess << "�v" << " - " << flush;
//
//if (answerGuess == generatedPasswordPattern)
//{
//	std::cout << "OPEN";
//}
//else
//{
//	std::cout << "NG";
//}
//
//cout << endl;
//
//std::cout << endl << answerGuess << endl;
//std::cout << endl << generatedPasswordPattern << endl;