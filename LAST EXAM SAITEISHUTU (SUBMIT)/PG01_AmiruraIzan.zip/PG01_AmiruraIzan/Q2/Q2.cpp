#include <iostream>
#include <string>
#include <sstream>

using namespace std;


int main()
{
	//Duck counter

	//3 5 3 1
	//5 3 1 4 3 1
	//3 3 3 3
	//10 3 1 5 4 3 1 4 3 3 1
	//50 1 3 2 2 2 1 2 5 4 4 5 3 1 2 2 5 4 2 5 3 3 1 4 5 2 2 4 2 1 3 3 4 3 1 4 2 1 4 4 5 3 3 3 4 3 5 4 2 5 5
	//100 3 4 1 5 3 5 5 1 1 3 1 2 2 4 5 3 3 4 2 3 1 2 5 4 2 2 3 2 1 4 2 2 1 3 3 4 4 4 1 4 5 5 5 1 3 2 3 5 3 2 4 1 5 4 1 4 5 5 4 5 5 1 2 3 4 2 1 2 1 5 1 1 2 2 1 5 3 5 1 1 1 3 2 3 4 1 3 4 5 2 2 5 3 3 1 5 4 5 5 2

	const int SAMPLE_AMOUNT = 6;

	int boxesCount[SAMPLE_AMOUNT];
	int excessDuck[SAMPLE_AMOUNT];
	int deficientDuck[SAMPLE_AMOUNT];

	string input;

	for (int i = 0;i < SAMPLE_AMOUNT ; i++)
	{
		getline(cin, input);

		int duckCount = 0;
		
		deficientDuck[i] = 0;
		excessDuck[i] = 0;
		
		//����
		stringstream inputSstr(input);
		inputSstr >> boxesCount[i];

		//Ducks that doesn't fit the box amount goes to others.
		while (inputSstr >> duckCount)
		{
			if (duckCount > 3)
			{
				excessDuck[i] += duckCount % 3;
			}
			else
			{
				deficientDuck[i] += 3 - duckCount;
			}
		}

	}
	
	//�o��
	for (int i = 0; i < SAMPLE_AMOUNT; i++)
	{
	printf("%3d", boxesCount[i]);
	std::cout << "���ł̉ߕs���́A";
	printf("%3d", excessDuck[i] + deficientDuck[i]);
	std::cout << "�ł��B" << endl;
	}

	system("pause");
	return 0;
}