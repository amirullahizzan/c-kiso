#include <iostream>
using namespace std;

int main()
{
	srand((unsigned int)(time(NULL)));

	for (int i = 0; i < 10; i++)
	{
		int randomnumber = rand() % 21 - 10;
		if (randomnumber >= 0)
		{
			printf_s("%3d", randomnumber);
			cout << " �́A�����ł��B" << endl;
		}
		else
		{
			printf_s("%3d", randomnumber);
			cout << " �́A�����ł��B" << endl;
		}
	}

	system("pause");
	return 0;
}