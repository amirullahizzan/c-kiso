#include <iostream>
#include <ctime>
using namespace std;

class Pos
{
public:
	void set(int _x, int _y)
	{
		x_ = _x;
		y_ = _y;
	}

	bool operator ==(const Pos _otherPos)
	{
		return x_ == _otherPos.x_ && y_ == _otherPos.y_;
	}

	int x()
	{
		return x_;
	}
	
	int y()
	{
		return y_;
	}

private:
	int x_, y_;
};

int main()
{
	srand((unsigned int)time(NULL));

	const int SIZE = 10;

	Pos base_pos;
	Pos positions[SIZE];

	base_pos.set(1, 2);

	int loop_counter = 0;
	while (true)
	{

		for (int i = 0; i < SIZE; ++i)
		{
			positions[i].set(rand() % 5, rand() % 5);
		}

		int counter = 0;
		for (int i = 0; i < SIZE; ++i)
		{
			if (base_pos == positions[i])
			{
				++counter;
			}
		}

		printf_s("x: %d, y: %d �Ɠ������W�́A%d����܂���\n",
				  base_pos.x(),
				  base_pos.y(),
				  counter);

		++loop_counter;
		if (loop_counter > 20)
			break;
	}

	system("pause");
	return 0;
}