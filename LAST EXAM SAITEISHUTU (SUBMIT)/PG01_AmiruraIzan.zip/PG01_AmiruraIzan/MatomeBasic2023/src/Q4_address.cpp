#include <iostream>
using namespace std;

int main()
{
	const int  n[] = { 1, 2, 3, 4 };
	const int* p[] = { &n[2], &n[0], &n[3], &n[1] };
	const int  i[] = { 1, 0, 2, 3 };

	for (int j = 0; j < 4; ++j)
	{
		// ��������
		cout << *p[i[j]] << endl;
		// �����܂�
	}

	system("pause");
	return 0;
}