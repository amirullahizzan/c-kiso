#include <iostream>
using namespace std;

int getInputNum()
{
	int num = 0;
	cout << "���l�̓��� > " << flush;
	cin >> num;

	return num;
}

int main()
{
	const int INPUT_NUM_COUNT = 10;
	int nums[INPUT_NUM_COUNT] = { 0 };

	for (int i = 0; i < INPUT_NUM_COUNT; ++i)
	{
		nums[i] = getInputNum();
	}

	int i;
	for (i = INPUT_NUM_COUNT-1; i >= 0;i-- )
	{
		printf_s("[%d]: %d\n", i, nums[i]);
	}

	system("pause");
	return 0;
}