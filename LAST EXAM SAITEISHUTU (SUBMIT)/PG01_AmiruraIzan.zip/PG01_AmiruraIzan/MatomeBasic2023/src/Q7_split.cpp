#include <iostream>
using namespace std;

int main()
{
	int input;
	while (true)
	{

	cout << "���l�̓��� > " << flush;
	cin >> input;
	if (input < -999 || input > 999)
	{
		cout << "ERROR: ���͂Ɍ�肪����܂�" << endl;
	}
	else
	{
		int hundredDigit = abs(input / 100);
		int dozenDigit   = abs(input % 100 / 10);
		int oneDigit	 = abs(input % 10);
		cout << "100�̈�: " << hundredDigit << endl;
		cout << " 10�̈�: " <<  dozenDigit << endl;
		cout << "  1�̈�: " <<   oneDigit << endl;
		break;
	}

	}

	system("pause");
	return 0;
}