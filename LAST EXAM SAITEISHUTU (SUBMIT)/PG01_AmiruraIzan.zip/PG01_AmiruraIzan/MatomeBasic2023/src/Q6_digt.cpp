#include <iostream>
#include <ctime>
using namespace std;

int getRandNum()
{
	int randomnumber = rand() % RAND_MAX+1;
	int randomnumber2 = rand() % RAND_MAX+1;
	int result = (randomnumber * randomnumber2) % 99999999;
	return result;
}

int main()
{
	srand((unsigned int)time(NULL));

	for (int i = 0; i < 100; ++i)
	{
		printf_s("%8d\n", getRandNum());
	}

	system("pause");
	return 0;
}