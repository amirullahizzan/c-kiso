#include <iostream>
using namespace std;

class Animal
{
protected:
	const char* name_;

public:

	virtual void sound()
	{

	}

	void showName() const
	{
		cout << name_ << flush;
	}
};

class Dog : public Animal
{
public:
	Dog()
	{
		name_ = "��";
	}
	void sound() override
	{
		showName();
		cout << ": " << "�����I" << endl;
	}
};

class Cat : public Animal
{
public:
	Cat()
	{
		name_ = "�L";
	}
	void sound() override
	{
		showName();
		cout << ": " << "�j���[��" << endl;
	}
};

void sound(Animal& animal)
{
	animal.sound();
}

int main()
{
	Dog dog;
	Cat cat;

	sound(dog);
	sound(cat);

	system("pause");
	return 0;
}