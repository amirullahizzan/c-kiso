#include <iostream>
using namespace std;

int getStringLength(const char* input)
{
	int wordCount = 0;
	//int inputSize = sizeof(inputSize) / inputSize[0];
	for (int i = 0; input[i] != '\0';i++)
	{
		wordCount++;
	}
	return wordCount;
}

int main()
{
	const char* STR_LIST[] =
	{
		 "Hello World"
		,"Programming"
		,"BlueSky"
		,"WinterWonderland"
		,"Epic Journey"
		,"SunnyDay"
		,"DigitalWorld"
		,"PeacefulOcean"
		,"DynamicFuture"
		,"HarmonyInNature"
		,"Infinite Possibilities"
		,"CreativeMind"
		,""
	};
	const int LIST_SIZE = sizeof(STR_LIST) / sizeof(STR_LIST[0]);

	for (int i = 0; i < LIST_SIZE; ++i)
	{
		printf_s("%s �̕������́A%d �ł��B\n",
				  STR_LIST[i], getStringLength(STR_LIST[i]));
	}

	system("pause");
	return 0;
}