#include <iostream>
using namespace std;

int main()
{
	srand((unsigned int)(time(NULL)));

	const int MAX_SAMPLE_VARIETY = 10;
	int storedrandomizeCount[MAX_SAMPLE_VARIETY+1];
	for (int i = 0; i <= MAX_SAMPLE_VARIETY; i++)
	{
		storedrandomizeCount[i] = 0;
	}

	const int MAX_SAMPLE_AMOUNT = 50;
	//RANDOMIZE AND DATA SAMPLING
	for (int i = 1; i <= MAX_SAMPLE_AMOUNT; i++)
	{
		int randomizednumber = rand()%11;
		printf("%4d ", randomizednumber);
		storedrandomizeCount[randomizednumber] += 1;

		if (i % 10 == 0 && i != 0)
		{
			cout << endl;
		}
	}
	
	//SORTER
	int modeNumber = 0;
	int highest_modeAmount = storedrandomizeCount[0];
	for (int i = 0; i < MAX_SAMPLE_VARIETY; i++)
	{
		if (storedrandomizeCount[i] > highest_modeAmount)
		{
			highest_modeAmount = storedrandomizeCount[i];
			modeNumber = i;
		}
	}
	//cout << highest_modeAmount << storedrandomizeCount[0];
	cout << "�ŕp�l: " << modeNumber << endl;
	system("pause");
	return 0;
}