#pragma once

void GameInit();
void GameUpdate();
void GameDraw();
void GameExit();
